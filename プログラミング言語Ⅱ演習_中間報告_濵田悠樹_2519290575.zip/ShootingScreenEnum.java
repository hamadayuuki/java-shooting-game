
// ゲーム画面遷移用の 列挙型 を定義
public enum ShootingScreenEnum {
    START,
    GAME,
    GAMEOVER,
}
