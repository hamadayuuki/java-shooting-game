public class Enemy {
    public int x , y;

    public Enemy() {

    }

    public Enemy(int x , int y) {
        this.x = x;
        this.y = y;
    }
}